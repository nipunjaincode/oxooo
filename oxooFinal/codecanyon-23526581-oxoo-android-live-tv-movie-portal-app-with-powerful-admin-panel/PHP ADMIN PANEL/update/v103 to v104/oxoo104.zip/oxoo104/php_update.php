<?php
	$CI = get_instance();
	$CI->load->database();
	
	//update version
	$condition = array(
	    'title' => 'version'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'1.0.4';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'version';
		$data['value'] 	= 	'1.0.4';
		$CI->db->insert('config',$data);
	endif;

	//fix site name
	$condition = array(
	    'title' => 'site_name'
	);
	if($CI->db->get_where('config', $condition)->num_rows() == 0):
		$data['title'] 	= 	'site_name';
		$data['value'] 	= 	'My Site';
		$CI->db->insert('config',$data);
	endif;

	// preroll_ads_enable
	$condition = array(
	    'title' => 'preroll_ads_enable'
	);
	if($CI->db->get_where('config', $condition)->num_rows() == 0):
		$data['title'] 	= 	'preroll_ads_enable';
		$data['value'] 	= 	'0';
		$CI->db->insert('config',$data);
	endif;

	// preroll_ads_video
	$condition = array(
	    'title' => 'preroll_ads_video'
	);
	if($CI->db->get_where('config', $condition)->num_rows() == 0):
		$data['title'] 	= 	'preroll_ads_video';
		$data['value'] 	= 	'';
		$CI->db->insert('config',$data);
	endif;

	// admob_ads_enable
	$condition = array(
	    'title' => 'admob_ads_enable'
	);
	if($CI->db->get_where('config', $condition)->num_rows() == 0):
		$data['title'] 	= 	'admob_ads_enable';
		$data['value'] 	= 	'0';
		$CI->db->insert('config',$data);
	endif;


	// admob_app_id
	$condition = array(
	    'title' => 'admob_app_id'
	);
	if($CI->db->get_where('config', $condition)->num_rows() == 0):
		$data['title'] 	= 	'admob_app_id';
		$data['value'] 	= 	'xxxxxxxxxxxxxxxxx';
		$CI->db->insert('config',$data);
	endif;


	// admob_banner_ads_id
	$condition = array(
	    'title' => 'admob_banner_ads_id'
	);
	if($CI->db->get_where('config', $condition)->num_rows() == 0):
		$data['title'] 	= 	'admob_banner_ads_id';
		$data['value'] 	= 	'xxxxxxxxxxxx';
		$CI->db->insert('config',$data);
	endif;


	// admob_interstitial_ads_id
	$condition = array(
	    'title' => 'admob_interstitial_ads_id'
	);
	if($CI->db->get_where('config', $condition)->num_rows() == 0):
		$data['title'] 	= 	'admob_interstitial_ads_id';
		$data['value'] 	= 	'xxxxxxxxxxxxxxxxx';
		$CI->db->insert('config',$data);
	endif;


	// total_movie_in_slider
	$condition = array(
	    'title' => 'total_movie_in_slider'
	);
	if($CI->db->get_where('config', $condition)->num_rows() == 0):
		$data['title'] 	= 	'total_movie_in_slider';
		$data['value'] 	= 	'5';
		$CI->db->insert('config',$data);
	endif;
?>

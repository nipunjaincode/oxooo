<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();
	
	//update version
	$condition = array(
	    'title' => 'version'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'1.1.0';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'version';
		$data['value'] 	= 	'1.1.0';
		$CI->db->insert('config',$data);
	endif;


	// create program guide table
	$fields = array(
        'live_tv_program_guide_id' => array(
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
        ),
        'live_tv_id' => array(
                'type' => 'INT',
                'constraint' => 50,
                'null' => FALSE,
        ),
        'title' => array(
                'type' => 'VARCHAR',
                'constraint' => '250',
                'null' => FALSE,
        ),
        'video_url' => array(
                'type' => 'text',
                'null' => TRUE,
        ),
        'date' => array(
                'type' => 'date',
                'null' => FALSE,
        ),
        'time' => array(
                'type' => 'time',
                'null' => FALSE,
        ),
        'type' => array(
                'type' =>'ENUM("onaired","upcoming")',
                'null' => FALSE,
                'default' => 'upcoming',
        ),
        'status' => array(
                'type' => 'INT',
                'null' => FALSE,
                'default'=>'1',
        ),
	);	
	$CI->dbforge->add_field($fields);
	$CI->dbforge->add_key('live_tv_program_guide_id', TRUE);
	$CI->dbforge->create_table('live_tv_program_guide', TRUE);

	// modify download table
	$fields2 = array(
	        'resolution' => array(
	        	'type' => 'VARCHAR',
	        	'constraint' => 250,
	        	'null' => FALSE,
                'default'=>'720p',
            ),
            'file_size' => array(
	        	'type' => 'VARCHAR',
	        	'constraint' => 250,
	        	'null' => FALSE,
                'default'=>'00MB',
            ),
	);
	$CI->dbforge->add_column('download_link', $fields2);
?>

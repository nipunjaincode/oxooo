<?php
	$CI = get_instance();
	$CI->load->database();
	
	//update version
	$condition = array(
	    'title' => 'version'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'1.0.3';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'version';
		$data['value'] 	= 	'1.0.3';
		$CI->db->insert('config',$data);
	endif;

	//fix site name
	$condition = array(
	    'title' => 'site_name'
	);
	if($CI->db->get_where('config', $condition)->num_rows() == 0):
		$data['title'] 	= 	'site_name';
		$data['value'] 	= 	'My Site';
		$CI->db->insert('config',$data);
	endif;

	// preroll_ads_enable
	$data['title'] 	= 	'preroll_ads_enable';
	$data['value'] 	= 	'0';
	$CI->db->insert('config',$data);

	// preroll_ads_video
	$data['title'] 	= 	'preroll_ads_video';
	$data['value'] 	= 	'';
	$CI->db->insert('config',$data);

	// admob_ads_enable
	$data['title'] 	= 	'admob_ads_enable';
	$data['value'] 	= 	'0';
	$CI->db->insert('config',$data);


	// admob_app_id
	$data['title'] 	= 	'admob_app_id';
	$data['value'] 	= 	'xxxxxxxxxxxxxxxxx';
	$CI->db->insert('config',$data);


	// admob_banner_ads_id
	$data['title'] 	= 	'admob_banner_ads_id';
	$data['value'] 	= 	'xxxxxxxxxxxx';
	$CI->db->insert('config',$data);


	// admob_interstitial_ads_id
	$data['title'] 	= 	'admob_interstitial_ads_id';
	$data['value'] 	= 	'xxxxxxxxxxxxxxxxx';
	$CI->db->insert('config',$data);


	// total_movie_in_slider
	$data['title'] 	= 	'total_movie_in_slider';
	$data['value'] 	= 	'5';
	$CI->db->insert('config',$data);
?>

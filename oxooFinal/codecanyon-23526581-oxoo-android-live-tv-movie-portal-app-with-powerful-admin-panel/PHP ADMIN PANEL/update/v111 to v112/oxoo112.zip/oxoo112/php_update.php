<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();
	
	//update version
	$condition = array(
	    'title' => 'version'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'1.1.2';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'version';
		$data['value'] 	= 	'1.1.2';
		$CI->db->insert('config',$data);
	endif;

	//update app_menu
	$condition = array(
	    'title' => 'app_menu'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'vertical';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'app_menu';
		$data['value'] 	= 	'vertical';
		$CI->db->insert('config',$data);
	endif;

	//update app_program_guide_enable
	$condition = array(
	    'title' => 'app_program_guide_enable'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'true';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'app_program_guide_enable';
		$data['value'] 	= 	'true';
		$CI->db->insert('config',$data);
	endif;

	//update app_mandatory_login
	$condition = array(
	    'title' => 'app_mandatory_login'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'false';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'app_mandatory_login';
		$data['value'] 	= 	'false';
		$CI->db->insert('config',$data);
	endif;

	//update genre_visible
	$condition = array(
	    'title' => 'genre_visible'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'true';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'genre_visible';
		$data['value'] 	= 	'true';
		$CI->db->insert('config',$data);
	endif;

	//update genre_visible
	$condition = array(
	    'title' => 'country_visible'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'true';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'country_visible';
		$data['value'] 	= 	'true';
		$CI->db->insert('config',$data);
	endif;
	
?>

<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();
	
	//update version
	$condition = array(
	    'title' => 'version'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'1.1.4';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'version';
		$data['value'] 	= 	'1.1.4';
		$CI->db->insert('config',$data);
	endif;

	// get current ads config
	$admob_enable = $CI->db->get_where('config',array('title'=>'admob_ads_enable'))->first_row()->value;

	//update mobile_ads_enable
	$mobile_ads_enable = '0';
	if($admob_enable == '1'):
		$mobile_ads_enable = '1';
	endif;

	$condition = array(
	    'title' => 'mobile_ads_enable'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	$mobile_ads_enable;
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'mobile_ads_enable';
		$data['value'] 	= 	'0';
		$CI->db->insert('config',$data);
	endif;

	//add mobile_ads_network
	$condition = array(
	    'title' => 'mobile_ads_network'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	"admob";
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'mobile_ads_network';
		$data['value'] 	= 	"admob";
		$CI->db->insert('config',$data);
	endif;

	//add fan_native_ads_placement_id
	$condition = array(
	    'title' => 'fan_native_ads_placement_id'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	"xxxxxxxxxxxxxxx_xxxxxxxxxxxxxxx";
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'fan_native_ads_placement_id';
		$data['value'] 	= 	"xxxxxxxxxxxxxxx_xxxxxxxxxxxxxxx";
		$CI->db->insert('config',$data);
	endif;


	//add fan_banner_ads_placement_id
	$condition = array(
	    'title' => 'fan_banner_ads_placement_id'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	"xxxxxxxxxxxxxxx_xxxxxxxxxxxxxxx";
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'fan_banner_ads_placement_id';
		$data['value'] 	= 	"xxxxxxxxxxxxxxx_xxxxxxxxxxxxxxx";
		$CI->db->insert('config',$data);
	endif;


	//add fan_Interstitial_ads_placement_id
	$condition = array(
	    'title' => 'fan_Interstitial_ads_placement_id'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	"xxxxxxxxxxxxxxxxxxxxx_xxxxxxxxxxxxxxx";
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'fan_Interstitial_ads_placement_id';
		$data['value'] 	= 	"xxxxxxxxxxxxxxxxxxxxx_xxxxxxxxxxxxxxx";
		$CI->db->insert('config',$data);
	endif;


	//add startapp_app_id
	$condition = array(
	    'title' => 'startapp_app_id'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	"xxxxxxxxxx";
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'startapp_app_id';
		$data['value'] 	= 	"xxxxxxxxxx";
		$CI->db->insert('config',$data);
	endif;
	
?>
